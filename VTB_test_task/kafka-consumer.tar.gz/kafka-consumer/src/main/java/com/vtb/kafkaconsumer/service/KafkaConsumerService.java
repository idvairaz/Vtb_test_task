package com.vtb.kafkaconsumer.service;

public interface KafkaConsumerService {
    void consume(String message);

}
