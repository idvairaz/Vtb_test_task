package com.vtb.kafkaconsumer.config;

public class MetricsConfig {
}
